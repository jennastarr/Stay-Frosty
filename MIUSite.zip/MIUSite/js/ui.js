$(document).ready(function(){
	$('#datepicker') .datepicker();
});

$(function() {
		$( "#tabs" ).tabs();
});